# Infotact-Internship
The repository contains files and projects belongs to the Infotact Internship
